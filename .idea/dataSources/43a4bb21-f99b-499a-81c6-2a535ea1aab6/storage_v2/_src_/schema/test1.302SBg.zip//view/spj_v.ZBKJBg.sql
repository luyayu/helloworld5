create view spj_v as
select `test1`.`spj`.`sno` AS `sno`, `test1`.`spj`.`pno` AS `pno`, `test1`.`spj`.`qiy` AS `qiy`
from `test1`.`spj`
         join `test1`.`j`
where ((`test1`.`spj`.`jno` = `test1`.`j`.`jno`) and (`test1`.`j`.`jname` = '三建'));

